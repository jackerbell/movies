import React from 'react';
import "../css/footer.css"

const Footer = () => {
  return (
    <div id='footerWrap'>

    </div>
  );
};

export default Footer;