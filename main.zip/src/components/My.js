import React from 'react';

const My = () => {
  return (
    <div id='my'>
      My영역입니다.
    </div>
  );
};

export default My;