import React from 'react';

const Recommend = () => {
  return (
    <div id='recommend'>  
      추천 영역입니다.
    </div>
  );
};

export default Recommend;