import React from 'react';

const Category = () => {
  return (
    <div id='category'>
      카테고리 영역입니다.
    </div>
  );
};

export default Category;