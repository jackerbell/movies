import React from 'react';

const GenreList = () => {
  return (
    <div>
      
    </div>
  );
};

export default GenreList;